import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'exam_model.dart';
import 'exam_service.dart';
import '../app/router.dart';
import '../widgets/loading_indicator.dart';

class ExamController extends GetxController {
  final ExamService _examService = ExamService();

  final RxList<ExamModel> exams = <ExamModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxString selectedFilter = 'Todos'.obs;

  @override
  void onInit() {
    super.onInit();
    loadExams();
  }

  Future<void> loadExams() async {
    isLoading.value = true;
    try {
      final userExams = await _examService.getUserExams();
      exams.value = userExams;
    } catch (e) {
      Get.snackbar('Error', 'No se pudieron cargar los exámenes: $e');
    }
    isLoading.value = false;
  }

  List<ExamModel> get filteredExams {
    if (selectedFilter.value == 'Todos') {
      return exams;
    } else if (selectedFilter.value == 'Completados') {
      return exams.where((exam) => exam.isCompleted).toList();
    } else if (selectedFilter.value == 'Pendientes') {
      return exams.where((exam) => !exam.isCompleted).toList();
    }
    return exams.where((exam) => exam.subject == selectedFilter.value).toList();
  }

  void changeFilter(String filter) {
    selectedFilter.value = filter;
  }

  Future<void> deleteExam(String examId) async {
    try {
      await _examService.deleteExam(examId);
      exams.removeWhere((exam) => exam.id == examId);
      Get.snackbar('Éxito', 'Examen eliminado correctamente');
    } catch (e) {
      Get.snackbar('Error', 'No se pudo eliminar el examen: $e');
    }
  }

  void startExam(ExamModel exam) {
    Get.to(() => ExamTakingScreen(exam: exam));
  }

  void viewResults(ExamModel exam) {
    Get.to(() => ExamResultsScreen(exam: exam));
  }
}

class ExamScreen extends StatelessWidget {
  final ExamController controller = Get.put(ExamController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mis Exámenes'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: controller.loadExams,
          ),
        ],
      ),
      body: Column(
        children: [
          _buildFilterChips(),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return LoadingIndicator();
              }

              if (controller.filteredExams.isEmpty) {
                return _buildEmptyState();
              }

              return _buildExamList();
            }),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed(AppRoutes.examForm),
        icon: Icon(Icons.add),
        label: Text('Crear Examen'),
      ),
    );
  }

  Widget _buildFilterChips() {
    final filters = [
      'Todos',
      'Pendientes',
      'Completados',
      'Matemáticas',
      'Física',
      'Química',
      'Biología',
    ];

    return Container(
      height: 60,
      padding: EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16),
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final filter = filters[index];
          return Obx(
            () => Padding(
              padding: EdgeInsets.only(right: 8),
              child: FilterChip(
                label: Text(filter),
                selected: controller.selectedFilter.value == filter,
                onSelected: (_) => controller.changeFilter(filter),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.quiz_outlined, size: 80, color: Colors.grey),
          SizedBox(height: 16),
          Text(
            'No hay exámenes',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'Crea tu primer examen para comenzar',
            style: TextStyle(color: Colors.grey[600]),
          ),
          SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => Get.toNamed(AppRoutes.examForm),
            icon: Icon(Icons.add),
            label: Text('Crear Examen'),
          ),
        ],
      ),
    );
  }

  Widget _buildExamList() {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: controller.filteredExams.length,
      itemBuilder: (context, index) {
        final exam = controller.filteredExams[index];
        return _buildExamCard(exam);
      },
    );
  }

  Widget _buildExamCard(ExamModel exam) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exam.title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        exam.subject,
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton(
                  itemBuilder:
                      (context) => [
                        PopupMenuItem(
                          value: 'delete',
                          child: Row(
                            children: [
                              Icon(Icons.delete, color: Colors.red),
                              SizedBox(width: 8),
                              Text('Eliminar'),
                            ],
                          ),
                        ),
                      ],
                  onSelected: (value) {
                    if (value == 'delete') {
                      _showDeleteDialog(exam);
                    }
                  },
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                _buildInfoChip(Icons.psychology, exam.difficulty),
                SizedBox(width: 8),
                _buildInfoChip(Icons.quiz, '${exam.questionCount} preguntas'),
                if (exam.timeLimit != null) ...[
                  SizedBox(width: 8),
                  _buildInfoChip(Icons.timer, '${exam.timeLimit} min'),
                ],
              ],
            ),
            if (exam.isCompleted) ...[
              SizedBox(height: 12),
              Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green, size: 16),
                  SizedBox(width: 4),
                  Text(
                    'Completado - ${exam.score}%',
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
            SizedBox(height: 16),
            Row(
              children: [
                if (!exam.isCompleted)
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => controller.startExam(exam),
                      icon: Icon(Icons.play_arrow),
                      label: Text('Iniciar Examen'),
                    ),
                  )
                else
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => controller.viewResults(exam),
                      icon: Icon(Icons.analytics),
                      label: Text('Ver Resultados'),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.grey[600]),
          SizedBox(width: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        ],
      ),
    );
  }

  void _showDeleteDialog(ExamModel exam) {
    Get.dialog(
      AlertDialog(
        title: Text('Eliminar Examen'),
        content: Text('¿Estás seguro de que deseas eliminar "${exam.title}"?'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('Cancelar')),
          TextButton(
            onPressed: () {
              Get.back();
              controller.deleteExam(exam.id);
            },
            child: Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

// Pantalla para tomar el examen
class ExamTakingScreen extends StatefulWidget {
  final ExamModel exam;

  ExamTakingScreen({required this.exam});

  @override
  _ExamTakingScreenState createState() => _ExamTakingScreenState();
}

class _ExamTakingScreenState extends State<ExamTakingScreen> {
  late PageController _pageController;
  int currentQuestion = 0;
  List<ExamQuestion> questions = [];

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    questions = List.from(widget.exam.questions);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.exam.title),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: (currentQuestion + 1) / questions.length,
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Pregunta ${currentQuestion + 1} de ${questions.length}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                if (widget.exam.timeLimit != null)
                  Icon(Icons.timer), // Aquí puedes agregar un timer
              ],
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              onPageChanged: (index) {
                setState(() {
                  currentQuestion = index;
                });
              },
              itemCount: questions.length,
              itemBuilder: (context, index) {
                return _buildQuestionCard(questions[index], index);
              },
            ),
          ),
          _buildNavigationButtons(),
        ],
      ),
    );
  }

  Widget _buildQuestionCard(ExamQuestion question, int index) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                question.question,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              if (question.type == 'multiple_choice')
                ...question.options.asMap().entries.map((entry) {
                  int optionIndex = entry.key;
                  String option = entry.value;
                  return RadioListTile<String>(
                    title: Text(option),
                    value: option,
                    groupValue: question.userAnswer,
                    onChanged: (value) {
                      setState(() {
                        question.userAnswer = value;
                      });
                    },
                  );
                }).toList()
              else if (question.type == 'open_ended')
                TextField(
                  maxLines: 5,
                  decoration: InputDecoration(
                    hintText: 'Escribe tu respuesta aquí...',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    question.userAnswer = value;
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Container(
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          if (currentQuestion > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  _pageController.previousPage(
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                },
                child: Text('Anterior'),
              ),
            ),
          if (currentQuestion > 0) SizedBox(width: 16),
          Expanded(
            child: ElevatedButton(
              onPressed: () {
                if (currentQuestion < questions.length - 1) {
                  _pageController.nextPage(
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                } else {
                  _showSubmitDialog();
                }
              },
              child: Text(
                currentQuestion < questions.length - 1
                    ? 'Siguiente'
                    : 'Finalizar',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSubmitDialog() {
    Get.dialog(
      AlertDialog(
        title: Text('Finalizar Examen'),
        content: Text('¿Estás seguro de que deseas enviar tu examen?'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('Revisar')),
          ElevatedButton(
            onPressed: () async {
              Get.back();
              await _submitExam();
            },
            child: Text('Enviar'),
          ),
        ],
      ),
    );
  }

  Future<void> _submitExam() async {
    try {
      final examService = ExamService();
      final completedExam = await examService.submitExam(
        widget.exam.id,
        questions,
      );

      Get.off(() => ExamResultsScreen(exam: completedExam));
    } catch (e) {
      Get.snackbar('Error', 'No se pudo enviar el examen: $e');
    }
  }
}

// Pantalla de resultados del examen
class ExamResultsScreen extends StatelessWidget {
  final ExamModel exam;

  ExamResultsScreen({required this.exam});

  @override
  Widget build(BuildContext context) {
    final correctAnswers = exam.questions.where((q) => q.isCorrect).length;
    final totalQuestions = exam.questions.length;
    final percentage = exam.score ?? 0;

    return Scaffold(
      appBar: AppBar(title: Text('Resultados del Examen')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            _buildScoreCard(correctAnswers, totalQuestions, percentage),
            SizedBox(height: 24),
            _buildQuestionReview(),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreCard(int correct, int total, int percentage) {
    Color scoreColor;
    String scoreMessage;

    if (percentage >= 90) {
      scoreColor = Colors.green;
      scoreMessage = '¡Excelente trabajo!';
    } else if (percentage >= 70) {
      scoreColor = Colors.orange;
      scoreMessage = '¡Buen trabajo!';
    } else {
      scoreColor = Colors.red;
      scoreMessage = 'Necesitas seguir practicando';
    }

    return Card(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(Icons.analytics, size: 80, color: scoreColor),
            SizedBox(height: 16),
            Text(
              '$percentage%',
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: scoreColor,
              ),
            ),
            Text(
              scoreMessage,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text(
                      '$correct',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    Text('Correctas'),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      '${total - correct}',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    Text('Incorrectas'),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      '$total',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Total'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionReview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Revisión de Preguntas',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 16),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: exam.questions.length,
          itemBuilder: (context, index) {
            final question = exam.questions[index];
            return _buildQuestionReviewCard(question, index + 1);
          },
        ),
      ],
    );
  }

  Widget _buildQuestionReviewCard(ExamQuestion question, int questionNumber) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Pregunta $questionNumber',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Spacer(),
                Icon(
                  question.isCorrect ? Icons.check_circle : Icons.cancel,
                  color: question.isCorrect ? Colors.green : Colors.red,
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(question.question, style: TextStyle(fontSize: 16)),
            SizedBox(height: 12),
            if (question.type == 'multiple_choice') ...[
              ...question.options.asMap().entries.map((entry) {
                int optionIndex = entry.key;
                String option = entry.value;
                bool isCorrect = optionIndex == question.correctAnswer;
                bool isUserAnswer = option == question.userAnswer;

                Color backgroundColor = Colors.transparent;
                Color textColor = Colors.black87;

                if (isCorrect) {
                  backgroundColor = Colors.green.withOpacity(0.1);
                  textColor = Colors.green.shade700;
                } else if (isUserAnswer && !isCorrect) {
                  backgroundColor = Colors.red.withOpacity(0.1);
                  textColor = Colors.red.shade700;
                }

                return Container(
                  margin: EdgeInsets.only(bottom: 4),
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: backgroundColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color:
                          isCorrect
                              ? Colors.green
                              : (isUserAnswer
                                  ? Colors.red
                                  : Colors.grey.shade300),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        isCorrect
                            ? Icons.check
                            : (isUserAnswer
                                ? Icons.close
                                : Icons.radio_button_unchecked),
                        color: textColor,
                        size: 20,
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(option, style: TextStyle(color: textColor)),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ] else if (question.type == 'open_ended') ...[
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color:
                      question.isCorrect
                          ? Colors.green.withOpacity(0.1)
                          : Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: question.isCorrect ? Colors.green : Colors.red,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Tu respuesta:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Text(question.userAnswer ?? 'Sin respuesta'),
                  ],
                ),
              ),
            ],
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.lightbulb, color: Colors.blue, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Explicación:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Text(
                    question.explanation,
                    style: TextStyle(color: Colors.blue.shade700),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
