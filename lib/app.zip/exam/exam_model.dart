class ExamModel {
  final String id;
  final String title;
  final String subject;
  final String difficulty;
  final int questionCount;
  final List<ExamQuestion> questions;
  final DateTime createdAt;
  final String userId;
  final int? timeLimit; // en minutos
  final bool isCompleted;
  final int? score;

  ExamModel({
    required this.id,
    required this.title,
    required this.subject,
    required this.difficulty,
    required this.questionCount,
    required this.questions,
    required this.createdAt,
    required this.userId,
    this.timeLimit,
    this.isCompleted = false,
    this.score,
  });

  factory ExamModel.fromJson(Map<String, dynamic> json) {
    return ExamModel(
      id: json['id'],
      title: json['title'],
      subject: json['subject'],
      difficulty: json['difficulty'],
      questionCount: json['question_count'],
      questions:
          (json['questions'] as List)
              .map((q) => ExamQuestion.fromJson(q))
              .toList(),
      createdAt: DateTime.parse(json['created_at']),
      userId: json['user_id'],
      timeLimit: json['time_limit'],
      isCompleted: json['is_completed'] ?? false,
      score: json['score'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'subject': subject,
      'difficulty': difficulty,
      'question_count': questionCount,
      'questions': questions.map((q) => q.toJson()).toList(),
      'created_at': createdAt.toIso8601String(),
      'user_id': userId,
      'time_limit': timeLimit,
      'is_completed': isCompleted,
      'score': score,
    };
  }

  ExamModel copyWith({
    String? id,
    String? title,
    String? subject,
    String? difficulty,
    int? questionCount,
    List<ExamQuestion>? questions,
    DateTime? createdAt,
    String? userId,
    int? timeLimit,
    bool? isCompleted,
    int? score,
  }) {
    return ExamModel(
      id: id ?? this.id,
      title: title ?? this.title,
      subject: subject ?? this.subject,
      difficulty: difficulty ?? this.difficulty,
      questionCount: questionCount ?? this.questionCount,
      questions: questions ?? this.questions,
      createdAt: createdAt ?? this.createdAt,
      userId: userId ?? this.userId,
      timeLimit: timeLimit ?? this.timeLimit,
      isCompleted: isCompleted ?? this.isCompleted,
      score: score ?? this.score,
    );
  }
}

class ExamQuestion {
  final String id;
  final String question;
  final List<String> options;
  final int correctAnswer;
  final String explanation;
  final String type; // 'multiple_choice', 'true_false', 'open_ended'
  String? userAnswer;
  bool isCorrect;

  ExamQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.correctAnswer,
    required this.explanation,
    required this.type,
    this.userAnswer,
    this.isCorrect = false,
  });

  factory ExamQuestion.fromJson(Map<String, dynamic> json) {
    return ExamQuestion(
      id: json['id'],
      question: json['question'],
      options: List<String>.from(json['options']),
      correctAnswer: json['correct_answer'],
      explanation: json['explanation'],
      type: json['type'],
      userAnswer: json['user_answer'],
      isCorrect: json['is_correct'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'question': question,
      'options': options,
      'correct_answer': correctAnswer,
      'explanation': explanation,
      'type': type,
      'user_answer': userAnswer,
      'is_correct': isCorrect,
    };
  }

  ExamQuestion copyWith({
    String? id,
    String? question,
    List<String>? options,
    int? correctAnswer,
    String? explanation,
    String? type,
    String? userAnswer,
    bool? isCorrect,
  }) {
    return ExamQuestion(
      id: id ?? this.id,
      question: question ?? this.question,
      options: options ?? this.options,
      correctAnswer: correctAnswer ?? this.correctAnswer,
      explanation: explanation ?? this.explanation,
      type: type ?? this.type,
      userAnswer: userAnswer ?? this.userAnswer,
      isCorrect: isCorrect ?? this.isCorrect,
    );
  }
}

class ExamSettings {
  final String subject;
  final String difficulty;
  final int questionCount;
  final int? timeLimit;
  final List<String> topics;
  final String questionType;

  ExamSettings({
    required this.subject,
    required this.difficulty,
    required this.questionCount,
    this.timeLimit,
    required this.topics,
    required this.questionType,
  });

  Map<String, dynamic> toJson() {
    return {
      'subject': subject,
      'difficulty': difficulty,
      'question_count': questionCount,
      'time_limit': timeLimit,
      'topics': topics,
      'question_type': questionType,
    };
  }
}
