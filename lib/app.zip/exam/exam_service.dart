import 'dart:convert';

import 'package:supabase_flutter/supabase_flutter.dart';
import '../ai/gemini_service.dart';
import 'exam_model.dart';

class ExamService {
  final SupabaseClient _supabase = Supabase.instance.client;
  final GeminiService _geminiService = GeminiService();

  Future<List<ExamModel>> getUserExams() async {
    final user = _supabase.auth.currentUser;
    if (user == null) throw Exception('Usuario no autenticado');

    final response = await _supabase
        .from('exams')
        .select()
        .eq('user_id', user.id)
        .order('created_at', ascending: false);

    return response.map<ExamModel>((json) => ExamModel.fromJson(json)).toList();
  }

  Future<ExamModel> createExam(ExamSettings settings) async {
    final user = _supabase.auth.currentUser;
    if (user == null) throw Exception('Usuario no autenticado');

    // Generar preguntas con Gemini
    final questions = await _generateQuestionsWithAI(settings);

    final examModel = ExamModel(
      id: '',
      title: 'Examen de ${settings.subject}',
      subject: settings.subject,
      difficulty: settings.difficulty,
      questionCount: settings.questionCount,
      questions: questions,
      createdAt: DateTime.now(),
      userId: user.id,
      timeLimit: settings.timeLimit,
    );

    // Guardar en Supabase
    final response =
        await _supabase
            .from('exams')
            .insert(examModel.toJson())
            .select()
            .single();

    return ExamModel.fromJson(response);
  }

  Future<ExamModel> createExamFromDocument(
    String documentContent,
    ExamSettings settings,
  ) async {
    final user = _supabase.auth.currentUser;
    if (user == null) throw Exception('Usuario no autenticado');

    // Generar preguntas basadas en el documento
    final questions = await _generateQuestionsFromDocument(
      documentContent,
      settings,
    );

    final examModel = ExamModel(
      id: '',
      title: 'Examen basado en documento - ${settings.subject}',
      subject: settings.subject,
      difficulty: settings.difficulty,
      questionCount: settings.questionCount,
      questions: questions,
      createdAt: DateTime.now(),
      userId: user.id,
      timeLimit: settings.timeLimit,
    );

    final response =
        await _supabase
            .from('exams')
            .insert(examModel.toJson())
            .select()
            .single();

    return ExamModel.fromJson(response);
  }

  Future<ExamModel> submitExam(
    String examId,
    List<ExamQuestion> answeredQuestions,
  ) async {
    final user = _supabase.auth.currentUser;
    if (user == null) throw Exception('Usuario no autenticado');

    // Calcular puntaje
    int score = 0;
    for (var question in answeredQuestions) {
      if (question.type == 'multiple_choice' || question.type == 'true_false') {
        if (question.userAnswer == question.options[question.correctAnswer]) {
          question.isCorrect = true;
          score++;
        }
      } else if (question.type == 'open_ended') {
        // Evaluar respuesta abierta con IA
        question.isCorrect = await _evaluateOpenEndedAnswer(
          question.question,
          question.userAnswer ?? '',
          question.explanation,
        );
        if (question.isCorrect) score++;
      }
    }

    final finalScore = ((score / answeredQuestions.length) * 100).round();

    // Actualizar examen en la base de datos
    await _supabase
        .from('exams')
        .update({
          'questions': answeredQuestions.map((q) => q.toJson()).toList(),
          'score': finalScore,
          'is_completed': true,
        })
        .eq('id', examId)
        .eq('user_id', user.id);

    // Obtener examen actualizado
    final response =
        await _supabase
            .from('exams')
            .select()
            .eq('id', examId)
            .eq('user_id', user.id)
            .single();

    return ExamModel.fromJson(response);
  }

  Future<void> deleteExam(String examId) async {
    final user = _supabase.auth.currentUser;
    if (user == null) throw Exception('Usuario no autenticado');

    await _supabase
        .from('exams')
        .delete()
        .eq('id', examId)
        .eq('user_id', user.id);
  }

  Future<List<ExamQuestion>> _generateQuestionsWithAI(
    ExamSettings settings,
  ) async {
    final prompt = '''
Genera ${settings.questionCount} preguntas de examen sobre ${settings.subject} con las siguientes características:
- Dificultad: ${settings.difficulty}
- Temas específicos: ${settings.topics.join(', ')}
- Tipo de pregunta: ${settings.questionType}

Para cada pregunta, proporciona:
1. La pregunta clara y específica
2. 4 opciones de respuesta (si es opción múltiple)
3. La respuesta correcta
4. Una explicación detallada de por qué es correcta

Formato de respuesta en JSON:
{
  "questions": [
    {
      "question": "texto de la pregunta",
      "options": ["opción 1", "opción 2", "opción 3", "opción 4"],
      "correct_answer": 0,
      "explanation": "explicación detallada",
      "type": "multiple_choice"
    }
  ]
}
''';

    final response = await _geminiService.generateContent(prompt);
    final questionsData = _parseQuestionsFromAI(response);

    return questionsData
        .map(
          (data) => ExamQuestion(
            id:
                DateTime.now().millisecondsSinceEpoch.toString() +
                data.hashCode.toString(),
            question: data['question'],
            options: List<String>.from(data['options']),
            correctAnswer: data['correct_answer'],
            explanation: data['explanation'],
            type: data['type'],
          ),
        )
        .toList();
  }

  Future<List<ExamQuestion>> _generateQuestionsFromDocument(
    String documentContent,
    ExamSettings settings,
  ) async {
    final prompt = '''
Basándote en el siguiente documento, genera ${settings.questionCount} preguntas de examen:

DOCUMENTO:
$documentContent

Características del examen:
- Dificultad: ${settings.difficulty}
- Tipo de pregunta: ${settings.questionType}

Las preguntas deben estar directamente relacionadas con el contenido del documento.
Proporciona el formato JSON igual que antes.
''';

    final response = await _geminiService.generateContent(prompt);
    final questionsData = _parseQuestionsFromAI(response);

    return questionsData
        .map(
          (data) => ExamQuestion(
            id:
                DateTime.now().millisecondsSinceEpoch.toString() +
                data.hashCode.toString(),
            question: data['question'],
            options: List<String>.from(data['options']),
            correctAnswer: data['correct_answer'],
            explanation: data['explanation'],
            type: data['type'],
          ),
        )
        .toList();
  }

  Future<bool> _evaluateOpenEndedAnswer(
    String question,
    String userAnswer,
    String correctAnswer,
  ) async {
    final prompt = '''
Evalúa si esta respuesta es correcta para la pregunta dada:

PREGUNTA: $question
RESPUESTA DEL ESTUDIANTE: $userAnswer
RESPUESTA ESPERADA: $correctAnswer

Responde solo "true" si la respuesta del estudiante es correcta o equivalente, o "false" si es incorrecta.
Considera sinónimos, paráfrasis y diferentes formas de expresar la misma idea.
''';

    final response = await _geminiService.generateContent(prompt);
    return response.trim().toLowerCase() == 'true';
  }

  List<Map<String, dynamic>> _parseQuestionsFromAI(String response) {
    try {
      // Limpiar la respuesta y extraer el JSON
      String jsonString = response;
      if (response.contains('```json')) {
        jsonString = response.split('```json')[1].split('```')[0];
      } else if (response.contains('```')) {
        jsonString = response.split('```')[1];
      }

      final Map<String, dynamic> parsed = jsonDecode(jsonString);
      return List<Map<String, dynamic>>.from(parsed['questions'] ?? []);
    } catch (e) {
      throw Exception('Error al parsear respuesta de IA: $e');
    }
  }
}
