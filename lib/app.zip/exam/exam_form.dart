import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:file_picker/file_picker.dart';
import 'exam_model.dart';
import 'exam_service.dart';
import '../documents/document_service.dart';
import '../widgets/custom_button.dart';
import '../widgets/loading_indicator.dart';

class ExamFormController extends GetxController {
  final ExamService _examService = ExamService();
  final DocumentService _documentService = DocumentService();

  final RxBool isLoading = false.obs;
  final RxBool hasDocument = false.obs;
  final RxString documentContent = ''.obs;
  final RxString documentName = ''.obs;

  // Form data
  final RxString selectedSubject = 'Matemáticas'.obs;
  final RxString selectedDifficulty = 'Intermedio'.obs;
  final RxInt questionCount = 10.obs;
  final RxInt timeLimit = 60.obs;
  final RxBool hasTimeLimit = true.obs;
  final RxString questionType = 'multiple_choice'.obs;
  final RxList<String> selectedTopics = <String>[].obs;

  final List<String> subjects = [
    'Matemáticas',
    'Física',
    'Química',
    'Biología',
    'Historia',
    'Geografía',
    'Literatura',
    'Inglés',
  ];

  final List<String> difficulties = ['Básico', 'Intermedio', 'Avanzado'];

  final List<String> questionTypes = [
    'multiple_choice',
    'true_false',
    'open_ended',
    'mixed',
  ];

  final Map<String, List<String>> subjectTopics = {
    'Matemáticas': [
      'Álgebra',
      'Geometría',
      'Cálculo',
      'Estadística',
      'Trigonometría',
      'Aritmética',
    ],
    'Física': [
      'Mecánica',
      'Termodinámica',
      'Electromagnetismo',
      'Óptica',
      'Física Moderna',
      'Ondas',
    ],
    'Química': [
      'Química Orgánica',
      'Química Inorgánica',
      'Bioquímica',
      'Química Analítica',
      'Fisicoquímica',
      'Estequiometría',
    ],
    'Biología': [
      'Biología Celular',
      'Genética',
      'Ecología',
      'Anatomía',
      'Fisiología',
      'Evolución',
    ],
  };

  List<String> get availableTopics =>
      subjectTopics[selectedSubject.value] ?? [];

  String get questionTypeLabel {
    switch (questionType.value) {
      case 'multiple_choice':
        return 'Opción Múltiple';
      case 'true_false':
        return 'Verdadero/Falso';
      case 'open_ended':
        return 'Respuesta Abierta';
      case 'mixed':
        return 'Mixto';
      default:
        return 'Opción Múltiple';
    }
  }

  Future<void> pickDocument() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'txt', 'doc', 'docx'],
      );

      if (result != null) {
        isLoading.value = true;
        final file = result.files.first;
        documentName.value = file.name;

        String content = await _documentService.extractTextFromFile(
          file.path!,
          file.extension ?? '',
        );

        documentContent.value = content;
        hasDocument.value = true;

        Get.snackbar('Éxito', 'Documento cargado correctamente');
      }
    } catch (e) {
      Get.snackbar('Error', 'No se pudo cargar el documento: $e');
    }
    isLoading.value = false;
  }

  void removeDocument() {
    hasDocument.value = false;
    documentContent.value = '';
    documentName.value = '';
  }

  void toggleTopic(String topic) {
    if (selectedTopics.contains(topic)) {
      selectedTopics.remove(topic);
    } else {
      selectedTopics.add(topic);
    }
  }

  Future<void> createExam() async {
    if (!_validateForm()) return;

    isLoading.value = true;
    try {
      final settings = ExamSettings(
        subject: selectedSubject.value,
        difficulty: selectedDifficulty.value,
        questionCount: questionCount.value,
        timeLimit: hasTimeLimit.value ? timeLimit.value : null,
        topics: selectedTopics.toList(),
        questionType: questionType.value,
      );

      ExamModel exam;
      if (hasDocument.value) {
        exam = await _examService.createExamFromDocument(
          documentContent.value,
          settings,
        );
      } else {
        exam = await _examService.createExam(settings);
      }

      Get.back(result: exam);
      Get.snackbar('Éxito', 'Examen creado correctamente');
    } catch (e) {
      Get.snackbar('Error', 'No se pudo crear el examen: $e');
    }
    isLoading.value = false;
  }

  bool _validateForm() {
    if (selectedTopics.isEmpty && !hasDocument.value) {
      Get.snackbar('Error', 'Selecciona al menos un tema o sube un documento');
      return false;
    }
    if (questionCount.value < 1 || questionCount.value > 50) {
      Get.snackbar('Error', 'El número de preguntas debe estar entre 1 y 50');
      return false;
    }
    return true;
  }
}

class ExamForm extends StatelessWidget {
  final ExamFormController controller = Get.put(ExamFormController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Crear Examen')),
      body: Obx(
        () => controller.isLoading.value ? LoadingIndicator() : _buildForm(),
      ),
    );
  }

  Widget _buildForm() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDocumentSection(),
          SizedBox(height: 24),
          _buildSubjectSection(),
          SizedBox(height: 24),
          _buildDifficultySection(),
          SizedBox(height: 24),
          _buildQuestionTypeSection(),
          SizedBox(height: 24),
          _buildQuestionCountSection(),
          SizedBox(height: 24),
          _buildTimeLimitSection(),
          SizedBox(height: 24),
          if (!controller.hasDocument.value) _buildTopicsSection(),
          SizedBox(height: 32),
          _buildCreateButton(),
        ],
      ),
    );
  }

  Widget _buildDocumentSection() {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Documento (Opcional)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Sube un documento para generar preguntas basadas en su contenido',
              style: TextStyle(color: Colors.grey[600]),
            ),
            SizedBox(height: 16),
            Obx(
              () =>
                  controller.hasDocument.value
                      ? _buildDocumentPreview()
                      : _buildDocumentUpload(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDocumentUpload() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!, style: BorderStyle.solid),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(Icons.cloud_upload, size: 48, color: Colors.grey),
          SizedBox(height: 16),
          Text(
            'Arrastra un archivo aquí o',
            style: TextStyle(color: Colors.grey[600]),
          ),
          SizedBox(height: 8),
          ElevatedButton(
            onPressed: controller.pickDocument,
            child: Text('Seleccionar Archivo'),
          ),
          SizedBox(height: 8),
          Text(
            'PDF, TXT, DOC, DOCX',
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentPreview() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green),
      ),
      child: Row(
        children: [
          Icon(Icons.description, color: Colors.green),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  controller.documentName.value,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  'Documento cargado correctamente',
                  style: TextStyle(color: Colors.green, fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: controller.removeDocument,
            icon: Icon(Icons.close, color: Colors.red),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Materia',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 12),
        Obx(
          () => Wrap(
            spacing: 8,
            runSpacing: 8,
            children:
                controller.subjects.map((subject) {
                  final isSelected =
                      controller.selectedSubject.value == subject;
                  return FilterChip(
                    label: Text(subject),
                    selected: isSelected,
                    onSelected: (_) {
                      controller.selectedSubject.value = subject;
                      controller.selectedTopics.clear();
                    },
                  );
                }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildDifficultySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Dificultad',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 12),
        Obx(
          () => Row(
            children:
                controller.difficulties.map((difficulty) {
                  final isSelected =
                      controller.selectedDifficulty.value == difficulty;
                  return Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(difficulty),
                        selected: isSelected,
                        onSelected:
                            (_) =>
                                controller.selectedDifficulty.value =
                                    difficulty,
                      ),
                    ),
                  );
                }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildQuestionTypeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tipo de Preguntas',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 12),
        Obx(
          () => DropdownButtonFormField<String>(
            value: controller.questionType.value,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            items:
                controller.questionTypes.map((type) {
                  String label = '';
                  switch (type) {
                    case 'multiple_choice':
                      label = 'Opción Múltiple';
                      break;
                    case 'true_false':
                      label = 'Verdadero/Falso';
                      break;
                    case 'open_ended':
                      label = 'Respuesta Abierta';
                      break;
                    case 'mixed':
                      label = 'Mixto';
                      break;
                  }
                  return DropdownMenuItem(value: type, child: Text(label));
                }).toList(),
            onChanged: (value) => controller.questionType.value = value!,
          ),
        ),
      ],
    );
  }

  Widget _buildQuestionCountSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Número de Preguntas',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 12),
        Obx(
          () => Row(
            children: [
              Expanded(
                child: Slider(
                  value: controller.questionCount.value.toDouble(),
                  min: 5,
                  max: 50,
                  divisions: 9,
                  label: controller.questionCount.value.toString(),
                  onChanged:
                      (value) => controller.questionCount.value = value.round(),
                ),
              ),
              SizedBox(width: 16),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${controller.questionCount.value}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTimeLimitSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Límite de Tiempo',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Spacer(),
            Obx(
              () => Switch(
                value: controller.hasTimeLimit.value,
                onChanged: (value) => controller.hasTimeLimit.value = value,
              ),
            ),
          ],
        ),
        Obx(
          () =>
              controller.hasTimeLimit.value
                  ? Column(
                    children: [
                      SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: Slider(
                              value: controller.timeLimit.value.toDouble(),
                              min: 15,
                              max: 180,
                              divisions: 11,
                              label: '${controller.timeLimit.value} min',
                              onChanged:
                                  (value) =>
                                      controller.timeLimit.value =
                                          value.round(),
                            ),
                          ),
                          SizedBox(width: 16),
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey[300]!),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              '${controller.timeLimit.value} min',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                  : SizedBox.shrink(),
        ),
      ],
    );
  }

  Widget _buildTopicsSection() {
    return Obx(
      () => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Temas',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'Selecciona los temas que deseas incluir en el examen',
            style: TextStyle(color: Colors.grey[600]),
          ),
          SizedBox(height: 12),
          if (controller.availableTopics.isNotEmpty)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  controller.availableTopics.map((topic) {
                    final isSelected = controller.selectedTopics.contains(
                      topic,
                    );
                    return FilterChip(
                      label: Text(topic),
                      selected: isSelected,
                      onSelected: (_) => controller.toggleTopic(topic),
                    );
                  }).toList(),
            )
          else
            Text(
              'No hay temas disponibles para esta materia',
              style: TextStyle(color: Colors.grey[500]),
            ),
        ],
      ),
    );
  }

  Widget _buildCreateButton() {
    return SizedBox(
      width: double.infinity,
      child: CustomButton(
        text: 'Crear Examen',
        onPressed: controller.createExam,
      ),
    );
  }
}
